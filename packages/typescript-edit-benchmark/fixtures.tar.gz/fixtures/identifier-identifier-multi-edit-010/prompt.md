# Fix a misspelled identifier in `cli.ts`

A recent edit misspelled the identifier `newlineIndex` as `enwlineIndex` in 3 places.

Replace every occurrence of `enwlineIndex` with `newlineIndex`. Do not change anything else.