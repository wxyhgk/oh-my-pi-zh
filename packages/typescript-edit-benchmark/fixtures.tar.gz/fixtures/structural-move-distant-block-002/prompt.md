# Fix a bug in `border-status-editor.ts`

The block starting with `function formatCwd(cwd: string): string {` was moved to the wrong place — it currently sits after `import { truncateToWidth, visibleWidth } from '@earendil-works/pi-tui';`. Move it back so it comes directly before `class EmptyFooter implements Component {`.

After the fix, the affected regions must read exactly:

Around line 10:

```ts
function fitBorder(
```

Around line 66:

```ts
function formatCwd(cwd: string): string {
  const home = process.env.HOME;
  if (home && cwd.startsWith(home)) {
    return `~${cwd.slice(home.length)}`;
  }
  return cwd;
}

function formatContext(ctx: ExtensionContext): string {
  const usage = ctx.getContextUsage();
  const contextWindow = usage?.contextWindow ?? ctx.model?.contextWindow;
  if (!contextWindow || !usage || usage.percent === null) {
    return 'ctx ?';
  }
  return `ctx ${Math.round(usage.percent)}%/${(contextWindow / 1000).toFixed(0)}k`;
}

function formatThinking(level: string): string {
  return level === 'off' ? 'off' : level;
}

class EmptyFooter implements Component {
```

Make exactly this change; do not modify anything else.