# Fix a bug in `branch-summarization.ts`

In this file's `switch`, the value in `case 'model_change':` must be handled exactly like the case after it: add a fall-through `case 'model_change':` label directly before `case 'custom':`.

After the fix, the affected region must read exactly:

Around line 179:

```ts
    case 'thinking_level_change':
    case 'model_change':
    case 'custom':
```

Make exactly this change; do not modify anything else.