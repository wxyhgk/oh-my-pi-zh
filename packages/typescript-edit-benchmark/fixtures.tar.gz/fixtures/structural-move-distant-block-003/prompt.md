# Fix a bug in `env-api-keys.ts`

The block starting with `function hasVertexAdcCredentials(env?: ProviderEnv): boolean {` was moved to the wrong place — it currently sits after `export function getEnvApiKey(provider: KnownProvider, env?: ProviderEnv): string | undefined;`. Move it back so it comes directly before `function getApiKeyEnvVars(provider: string): readonly string[] | undefined {`.

After the fix, the affected regions must read exactly:

Around line 35:

```ts
function hasVertexAdcCredentials(env?: ProviderEnv): boolean {
  const explicitCredentialsPath = env?.GOOGLE_APPLICATION_CREDENTIALS;
  if (explicitCredentialsPath) {
    return _existsSync ? _existsSync(explicitCredentialsPath) : false;
  }

  if (cachedVertexAdcCredentialsExists === null) {
    // If node modules haven't loaded yet (async import race at startup),
    // return false WITHOUT caching so the next call retries once they're ready.
    // Only cache false permanently in a browser environment where fs is never available.
    if (!_existsSync || !_homedir || !_join) {
      const isNode =
        typeof process !== 'undefined' && (process.versions?.node || process.versions?.bun);
      if (!isNode) {
        // Definitively in a browser — safe to cache false permanently
        cachedVertexAdcCredentialsExists = false;
      }
      return false;
    }

    // Check GOOGLE_APPLICATION_CREDENTIALS env var first (standard way)
    const gacPath = getProviderEnvValue('GOOGLE_APPLICATION_CREDENTIALS', env);
    if (gacPath) {
      cachedVertexAdcCredentialsExists = _existsSync(gacPath);
    } else {
      // Fall back to default ADC path (lazy evaluation)
      cachedVertexAdcCredentialsExists = _existsSync(
        _join(_homedir(), '.config', 'gcloud', 'application_default_credentials.json'),
      );
    }
  }
  return cachedVertexAdcCredentialsExists;
}

function getApiKeyEnvVars(provider: string): readonly string[] | undefined {
```

Around line 109:

```ts
export function getEnvApiKey(provider: KnownProvider, env?: ProviderEnv): string | undefined;
```

Make exactly this change; do not modify anything else.