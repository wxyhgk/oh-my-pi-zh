# Fix a bug in `html.ts`

Two arguments in a call are swapped.

Replace this (starting on line 44):

```ts
  const entity = html.slice(semicolonIndex, index + 1);
```

with:

```ts
  const entity = html.slice(index + 1, semicolonIndex);
```

Make exactly this change; do not modify anything else.