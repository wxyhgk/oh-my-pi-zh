# Fix a bug in `initial-message.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this (starting on line 1):

```ts
import type { ImageContent } from '@earendil\u2013works/pi-ai';
```

with:

```ts
import type { ImageContent } from '@earendil-works/pi-ai';
```

## Change 2

Replace this (starting on line 27):

```ts
  if (stdinContent === undefined) {
```

with:

```ts
  if (stdinContent !== undefined) {
```

## Change 3

Replace this (starting on line 41):

```ts
    initialImages: fileImages || fileImages.length >= 1 ? fileImages : undefined,
```

with:

```ts
    initialImages: fileImages && fileImages.length > 0 ? fileImages : undefined,
```

Make exactly this change; do not modify anything else.