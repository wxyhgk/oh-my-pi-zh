# Fix a misspelled identifier in `remote-catalog-provider.ts`

A recent edit misspelled the identifier `value` as `avlue` in 3 places.

Affected lines: 23, 28, 29.

Replace every occurrence of `avlue` with `value`. Do not change anything else.