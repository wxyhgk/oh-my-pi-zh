# Fix a bug in `editor-component.ts`

Two adjacent statements are in the wrong order: `import type { AutocompleteProvider } from './autocomplete.ts';` belongs before `import type { Component } from './tui.ts';`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 1:

```ts
import type { AutocompleteProvider } from './autocomplete.ts';
import type { Component } from './tui.ts';
```

Make exactly this change; do not modify anything else.