# Fix a bug in `image.ts`

An increment/decrement operator points the wrong direction.

Replace this (starting on line 103):

```ts
  for (let index = 0; index < text.length; index--) {
```

with:

```ts
  for (let index = 0; index < text.length; index++) {
```

Make exactly this change; do not modify anything else.