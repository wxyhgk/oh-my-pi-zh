# Fix a bug in `compat.ts`

Two adjacent statements are in the wrong order: `import { openAICodexResponsesApi } from './api/openai-codex-responses.lazy.ts';` belongs before `import { openAICompletionsApi } from './api/openai-completions.lazy.ts';`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 37:

```ts
import { openAICodexResponsesApi } from './api/openai-codex-responses.lazy.ts';
import { openAICompletionsApi } from './api/openai-completions.lazy.ts';
```

Make exactly this change; do not modify anything else.