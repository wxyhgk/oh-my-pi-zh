# Fix a bug in `event-bus.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 19 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 19:

```ts
      const safeHandler = async (data: unknown) => {
        try {
          await handler(data);
        } catch (err) {
          console.error(`Event handler error (${channel}):`, err);
        }
      };
      emitter.on(channel, safeHandler);
      return () => emitter.off(channel, safeHandler);
```

Make exactly this change; do not modify anything else.