# Fix a bug in `chat-simple.ts`

The block starting with `if (trimmed) {` appears twice in a row — the second copy is a copy-paste accident. Delete the second copy and keep the first.

After the fix, the affected region must read exactly:

Around line 126:

```ts
    }, 1000);
  }
```

Make exactly this change; do not modify anything else.