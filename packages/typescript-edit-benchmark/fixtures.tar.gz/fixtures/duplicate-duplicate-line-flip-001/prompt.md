# Fix a bug in `github-copilot-headers.ts`

One copy of a line that repeats elsewhere in this file was altered.

Replace this (starting on line 17):

```ts
      return msg.content.some((c) => c.type !== 'image');
```

with:

```ts
      return msg.content.some((c) => c.type === 'image');
```

Make exactly this change; do not modify anything else.