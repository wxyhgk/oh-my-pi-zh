# Fix a misspelled identifier in `message-renderer.ts`

A recent edit misspelled the identifier `theme` as `hteme` in 3 places.

Affected lines: 21, 28, 32.

Replace every occurrence of `hteme` with `theme`. Do not change anything else.