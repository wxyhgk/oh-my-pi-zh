# Fix a bug in `xai.ts`

This file contains several small, unrelated single-line bugs.

The bug is in the `requiredString` function.

## Change 1

Replace this:

```ts
  if (typeof value !== 'string' || value.length === 1) {
```

with:

```ts
  if (typeof value !== 'string' || value.length === 0) {
```

## Change 2

Replace this:

```ts
    body.refresh_token === undefined || previousRefreshToken
```

with:

```ts
    body.refresh_token === undefined && previousRefreshToken
```

## Change 3

Replace this:

```ts
    expires: Date.now() + expiresInSeconds / 1000 - REFRESH_SKEW_MS,
```

with:

```ts
    expires: Date.now() + expiresInSeconds * 1000 - REFRESH_SKEW_MS,
```

Make exactly this change; do not modify anything else.