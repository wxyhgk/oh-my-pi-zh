# Fix a bug in `keybindings.ts`

The block starting with `export function migrateKeybindingsConfig(rawConfig: Record<string, unknown>): {` was moved to the wrong place — it currently sits after `export type { Keybinding, KeyId, KeybindingsConfig };`. Move it back so it comes directly before `function orderKeybindingsConfig(config: Record<string, unknown>): Record<string, unknown> {`.

After the fix, the affected regions must read exactly:

Around line 291:

```ts
export function migrateKeybindingsConfig(rawConfig: Record<string, unknown>): {
  config: Record<string, unknown>;
  migrated: boolean;
} {
  const config: Record<string, unknown> = {};
  let migrated = false;

  for (const [key, value] of Object.entries(rawConfig)) {
    const nextKey = isLegacyKeybindingName(key) ? KEYBINDING_NAME_MIGRATIONS[key] : key;
    if (nextKey !== key) {
      migrated = true;
    }
    if (key !== nextKey && Object.hasOwn(rawConfig, nextKey)) {
      migrated = true;
      continue;
    }
    config[nextKey] = value;
  }

  return { config: orderKeybindingsConfig(config), migrated };
}

function orderKeybindingsConfig(config: Record<string, unknown>): Record<string, unknown> {
```

Around line 350:

```ts
export type { Keybinding, KeyId, KeybindingsConfig };
```

Make exactly this change; do not modify anything else.