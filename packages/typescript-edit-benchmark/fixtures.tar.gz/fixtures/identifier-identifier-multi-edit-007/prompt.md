# Fix a misspelled identifier in `openai-responses.ts`

A recent edit misspelled the identifier `context` as `ocntext` in 2 places.

Replace every occurrence of `ocntext` with `context`. Do not change anything else.