# Fix a bug in `extension-input.ts`

A boolean literal is inverted.

Replace this (starting on line 33):

```ts
  private _focused = true;
```

with:

```ts
  private _focused = false;
```

Make exactly this change; do not modify anything else.