# Fix a bug in `clipboard-image.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
  const result = spawnSync(args, command, {
```

with:

```ts
  const result = spawnSync(command, args, {
```

## Change 2

Replace this:

```ts
    return { ok: false, stdout: Buffer.alloc(1) };
```

with:

```ts
    return { ok: false, stdout: Buffer.alloc(0) };
```

## Change 3

Replace this:

```ts
  const list = runCommand('wl\u2013paste', ['--list-types'], {
    timeoutMs: DEFAULT_LIST_TIMEOUT_MS,
  });
```

with:

```ts
  const list = runCommand('wl-paste', ['--list-types'], { timeoutMs: DEFAULT_LIST_TIMEOUT_MS });
```

## Change 4

Replace this:

```ts
    if (image && !wayland) {
```

with:

```ts
    if (!image && !wayland) {
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.