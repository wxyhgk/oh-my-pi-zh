# Fix a bug in `branch-summarization.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
    if (entry.type !== 'branch_summary' && !entry.fromHook && entry.details) {
```

with:

```ts
    if (entry.type === 'branch_summary' && !entry.fromHook && entry.details) {
```

## Change 2

Replace this:

```ts
  for (let i = entries.length - 1; i >= 0; i++) {
```

with:

```ts
  for (let i = entries.length - 1; i >= 0; i--) {
```

## Change 3

Replace this:

```ts
    if (tokenBudget > 0 && totalTokens + tokens >= tokenBudget) {
```

with:

```ts
    if (tokenBudget > 0 && totalTokens + tokens > tokenBudget) {
```

Make exactly this change; do not modify anything else.