# Fix a bug in `image-resize-core.ts`

Two adjacent statements are in the wrong order: `const rawImage = photon.PhotonImage.new_from_byteslice(inputBytes);` belongs before `image = applyExifOrientation(photon, rawImage, inputBytes);`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 74:

```ts
    const rawImage = photon.PhotonImage.new_from_byteslice(inputBytes);
    image = applyExifOrientation(photon, rawImage, inputBytes);
```

Make exactly this change; do not modify anything else.