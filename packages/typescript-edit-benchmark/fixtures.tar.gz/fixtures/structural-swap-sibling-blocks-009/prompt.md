# Fix a bug in `simple-options.ts`

Two adjacent blocks are in the wrong order: the block starting with `export function clampReasoning(` belongs before the block starting with `export function adjustMaxTokensForThinking(`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 53:

```ts
export function clampReasoning(
  effort: ThinkingLevel | undefined,
): Exclude<ThinkingLevel, 'xhigh' | 'max'> | undefined {
  return effort === 'xhigh' || effort === 'max' ? 'high' : effort;
}

export function adjustMaxTokensForThinking(
```

Around line 81:

```ts
}
```

Make exactly this change; do not modify anything else.