# Fix a bug in `ansi-to-html.ts`

Two adjacent blocks are in the wrong order: the block starting with `interface TextStyle {` belongs before the block starting with `function createEmptyStyle(): TextStyle {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 72:

```ts
interface TextStyle {
  fg: string | null;
  bg: string | null;
  bold: boolean;
  dim: boolean;
  italic: boolean;
  underline: boolean;
}

function createEmptyStyle(): TextStyle {
```

Around line 83:

```ts
function styleToInlineCSS(style: TextStyle): string {
```

Make exactly this change; do not modify anything else.