# Fix a bug in `tool-override.ts`

A regex quantifier was swapped, changing whitespace matching.

Replace this (starting on line 39):

```ts
  /\.env\..*$/,
```

with:

```ts
  /\.env\..+$/,
```

Make exactly this change; do not modify anything else.