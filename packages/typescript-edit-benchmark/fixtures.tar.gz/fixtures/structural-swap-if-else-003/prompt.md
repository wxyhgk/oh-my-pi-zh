# Fix a bug in `write.ts`

The branch bodies of `if (fileContent !== null) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected regions must read exactly:

Around line 253:

```ts
      if (fileContent !== null) {
```

Around line 258:

```ts
          : updateWriteHighlightCacheIncremental(component.cache, rawPath, fileContent);
      } else {
        component.cache = undefined;
```

Make exactly this change; do not modify anything else.