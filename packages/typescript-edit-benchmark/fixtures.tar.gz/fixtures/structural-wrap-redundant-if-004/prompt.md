# Fix a bug in `nodejs.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 482 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 482:

```ts
        stdout += chunk;
        try {
          options?.onStdout?.(chunk);
        } catch (error) {
          const cause = toError(error);
          callbackError = new ExecutionError('callback_error', cause.message, cause);
          onAbort();
```

Make exactly this change; do not modify anything else.