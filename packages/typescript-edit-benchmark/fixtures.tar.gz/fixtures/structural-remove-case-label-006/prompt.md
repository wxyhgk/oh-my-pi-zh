# Fix a bug in `branch-summarization.ts`

In this file's `switch`, the value in `case 'active_tools_change':` must be handled exactly like the case after it: add a fall-through `case 'active_tools_change':` label directly before `case 'custom':`.

After the fix, the affected region must read exactly:

Around line 132:

```ts
    case 'model_change':
    case 'active_tools_change':
    case 'custom':
```

Make exactly this change; do not modify anything else.