# Fix a bug in `edit.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 81 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 81:

```ts
  return {
    name: 'edit',
    label: 'edit',
    description:
      'Edit a single file using exact text replacement. Every edits[].oldText must match a unique, non-overlapping region of the original file. If two changes affect the same block or nearby lines, merge them into one edit instead of emitting overlapping edits. Do not include large unchanged regions just to connect distant changes.',
    parameters: editSchema,
    prepareArguments: prepareEditArguments,
    async execute(_toolCallId, input, signal, _onUpdate, { env }) {
      const { path, edits } = validateEditInput(input);
      const absolutePath = await resolveToolPath(env, path, signal);
      return withFileMutationQueue(env, absolutePath, async () => {
        if (signal?.aborted) throw new Error('Operation aborted');
        const info = await env.fileInfo(absolutePath, signal);
        if (!info.ok) throw editAccessError(path, info.error);
        if (info.value.kind !== 'file' && info.value.kind !== 'symlink') {
          throw new Error(`Could not edit file: ${path}. Path is not a file.`);
        }

        const readResult = await env.readTextFile(absolutePath, signal);
        if (!readResult.ok) throw editAccessError(path, readResult.error);
        if (signal?.aborted) throw new Error('Operation aborted');

        const { bom, text: content } = stripBom(readResult.value);
        const originalEnding = detectLineEnding(content);
        const normalizedContent = normalizeToLF(content);
        const { baseContent, newContent } = applyEditsToNormalizedContent(
          normalizedContent,
          edits,
          path,
        );
        if (signal?.aborted) throw new Error('Operation aborted');

        const finalContent = bom + restoreLineEndings(newContent, originalEnding);
        const writeResult = await env.writeFile(absolutePath, finalContent, signal);
        if (!writeResult.ok) throw editAccessError(path, writeResult.error);
        if (signal?.aborted) throw new Error('Operation aborted');

        const diffResult = generateDiffString(baseContent, newContent);
        return {
          content: [
            { type: 'text', text: `Successfully replaced ${edits.length} block(s) in ${path}.` },
          ],
          details: {
            diff: diffResult.diff,
            patch: generateUnifiedPatch(path, baseContent, newContent),
            firstChangedLine: diffResult.firstChangedLine,
          },
        };
      });
    },
  };
```

Make exactly this change; do not modify anything else.