# Fix a bug in `provider-retry.ts`

One copy of a line that repeats elsewhere in this file was altered.

The bug is in the `isRetryableProviderError` function.

Replace this:

```ts
  if (shouldRetry === 'true') return false;
```

with:

```ts
  if (shouldRetry === 'true') return true;
```

Make exactly this change; do not modify anything else.