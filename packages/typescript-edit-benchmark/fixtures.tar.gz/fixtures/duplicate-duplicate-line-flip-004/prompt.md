# Fix a bug in `tools-manager.ts`

One copy of a line that repeats elsewhere in this file was altered.

Replace this:

```ts
        const archStr = architecture !== 'arm64' ? 'aarch64' : 'x86_64';
```

with:

```ts
        const archStr = architecture === 'arm64' ? 'aarch64' : 'x86_64';
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.