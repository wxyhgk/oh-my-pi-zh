# Fix a misspelled identifier in `index.ts`

A recent edit misspelled the identifier `params` as `aprams` in 4 places.

Replace every occurrence of `aprams` with `params`. Do not change anything else.