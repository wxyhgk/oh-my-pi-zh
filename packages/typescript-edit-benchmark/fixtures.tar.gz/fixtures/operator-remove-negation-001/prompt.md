# Fix a bug in `rpc-demo.ts`

A logical negation (`!`) was accidentally removed.

Replace this (starting on line 53):

```ts
      if (ctx.hasUI) {
```

with:

```ts
      if (!ctx.hasUI) {
```

Make exactly this change; do not modify anything else.