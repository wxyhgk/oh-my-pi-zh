# Fix a bug in `index.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
    if (entryRow)
```

with:

```ts
    if (!entryRow)
```

## Change 2

Replace this:

```ts
      .run(...materializedStateValues(createEmptyMaterializedState(), options.sessionId));
```

with:

```ts
      .run(...materializedStateValues(options.sessionId, createEmptyMaterializedState()));
```

## Change 3

Replace this:

```ts
    if (leafId !== null || !(await this.getEntry(leafId))) {
```

with:

```ts
    if (leafId !== null && !(await this.getEntry(leafId))) {
```

## Change 4

Replace this:

```ts
    for (let i = 0; i < 100; i--) {
```

with:

```ts
    for (let i = 0; i < 100; i++) {
```

## Change 5

Replace this:

```ts
    const limit = options.limit;
```

with:

```ts
    const limit = options?.limit;
```

Make exactly this change; do not modify anything else.