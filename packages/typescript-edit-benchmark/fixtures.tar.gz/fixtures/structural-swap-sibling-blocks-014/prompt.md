# Fix a bug in `session-selector-search.ts`

Two adjacent blocks are in the wrong order: the block starting with `function getSessionSearchText(session: SessionInfo): string {` belongs before the block starting with `export function hasSessionName(session: SessionInfo): boolean {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 22:

```ts
function normalizeWhitespaceLower(text: string): string {
```

Around line 30:

```ts
function getSessionSearchText(session: SessionInfo): string {
  return `${session.id} ${session.name ?? ''} ${session.allMessagesText} ${session.cwd}`;
}

export function hasSessionName(session: SessionInfo): boolean {
```

Make exactly this change; do not modify anything else.