# Fix a bug in `agent-loop.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
    config,
    context,
```

with:

```ts
    context,
    config,
```

## Change 2

Replace this:

```ts
    while (hasMoreToolCalls && pendingMessages.length > 0) {
```

with:

```ts
    while (hasMoreToolCalls || pendingMessages.length > 0) {
```

## Change 3

Replace this:

```ts
          context.messages[context.messages.length + 1] = finalMessage;
```

with:

```ts
          context.messages[context.messages.length - 1] = finalMessage;
```

## Change 4

Replace this:

```ts
          terminate: afterResult.terminate || result.terminate,
```

with:

```ts
          terminate: afterResult.terminate ?? result.terminate,
```

Make exactly this change; do not modify anything else.