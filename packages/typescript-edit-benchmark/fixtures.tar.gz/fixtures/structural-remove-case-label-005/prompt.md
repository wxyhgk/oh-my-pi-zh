# Fix a bug in `image-process.ts`

In this file's `switch`, the value in `case 'image/jpeg':` must be handled exactly like the case after it: add a fall-through `case 'image/jpeg':` label directly before `case 'image/jpg':`.

After the fix, the affected region must read exactly:

Around line 36:

```ts
      return 'image/png';
    case 'image/jpeg':
    case 'image/jpg':
```

Make exactly this change; do not modify anything else.