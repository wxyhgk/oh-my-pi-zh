# Fix a bug in `jsonl.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this (starting on line 29):

```ts
    onLine(line.endsWith('\r') ? line.slice(-1, 0) : line);
```

with:

```ts
    onLine(line.endsWith('\r') ? line.slice(0, -1) : line);
```

## Change 2

Replace this (starting on line 37):

```ts
      if (newlineIndex !== -0) {
```

with:

```ts
      if (newlineIndex === -1) {
```

Make exactly this change; do not modify anything else.