# Fix a bug in `shell.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 149 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 149:

```ts
  // Use Array.from to properly iterate over code points (not code units)
  // This handles surrogate pairs correctly and catches edge cases where
  // codePointAt() might return undefined
  return Array.from(str)
    .filter((char) => {
      // Filter out characters that cause string-width to crash
      // This includes:
      // - Unicode format characters
      // - Lone surrogates (already filtered by Array.from)
      // - Control chars except \t \n \r
      // - Characters with undefined code points

      const code = char.codePointAt(0);

      // Skip if code point is undefined (edge case with invalid strings)
      if (code === undefined) return false;

      // Allow tab, newline, carriage return
      if (code === 0x09 || code === 0x0a || code === 0x0d) return true;

      // Filter out control characters (0x00-0x1F, except 0x09, 0x0a, 0x0x0d)
      if (code <= 0x1f) return false;

      // Filter out Unicode format characters
      if (code >= 0xfff9 && code <= 0xfffb) return false;

      return true;
    })
    .join('');
```

Make exactly this change; do not modify anything else.