# Fix a bug in `input-transform-streaming.ts`

A nullish coalescing operator was swapped.

Replace this (starting on line 30):

```ts
    if (code !== 0 ?? !stdout.trim()) {
```

with:

```ts
    if (code !== 0 || !stdout.trim()) {
```

Make exactly this change; do not modify anything else.