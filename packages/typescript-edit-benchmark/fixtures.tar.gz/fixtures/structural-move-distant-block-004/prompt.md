# Fix a bug in `test-theme-colors.ts`

The block starting with `const parseAnsiRgb = (ansi: string): [number, number, number] | null => {` was moved to the wrong place — it currently sits after `console.log('toolPendingBg:', theme.bg('toolPendingBg', ' Sample '));`. Move it back so it comes directly before `const getContrastVsWhite = (colorName: string): string => {`.

After the fix, the affected regions must read exactly:

Around line 185:

```ts
  const parseAnsiRgb = (ansi: string): [number, number, number] | null => {
    const match = ansi.match(/38;2;(\d+);(\d+);(\d+)/);
    return match ? [parseInt(match[1], 10), parseInt(match[2], 10), parseInt(match[3], 10)] : null;
  };

  const getContrastVsWhite = (colorName: string): string => {
```

Around line 246:

```ts
  console.log('toolPendingBg:', theme.bg('toolPendingBg', ' Sample '));
```

Make exactly this change; do not modify anything else.