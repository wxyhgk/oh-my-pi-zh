# Fix a bug in `12-full-control.ts`

Two adjacent blocks are in the wrong order: the block starting with `const { session } = await createAgentSession({` belongs before the block starting with `try {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 51:

```ts
const { session } = await createAgentSession({
  cwd,
  agentDir: '/tmp/my-agent',
  model,
  thinkingLevel: 'off',
  modelRuntime,
  resourceLoader,
  tools: ['read', 'bash'],
  sessionManager: SessionManager.inMemory(cwd),
  settingsManager,
});

try {
```

Around line 62:

```ts
}
```

Make exactly this change; do not modify anything else.