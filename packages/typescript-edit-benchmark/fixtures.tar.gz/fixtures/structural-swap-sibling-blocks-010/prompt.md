# Fix a bug in `output-guard.ts`

Two adjacent blocks are in the wrong order: the block starting with `async function writeRawStdoutChunk(text: string): Promise<void> {` belongs before the block starting with `export function takeOverStdout(): void {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 20:

```ts
async function writeRawStdoutChunk(text: string): Promise<void> {
  while (true) {
    try {
      await new Promise<void>((resolve, reject) => {
        try {
          getRawStdoutWrite()(text, (error) => {
            if (error) reject(error);
            else resolve();
          });
        } catch (error) {
          reject(error instanceof Error ? error : new Error(String(error)));
        }
      });
      return;
    } catch (error) {
      const writeError = error instanceof Error ? error : new Error(String(error));
      const code = (writeError as Error & { code?: unknown }).code;
      if (code !== 'ENOBUFS' && code !== 'EAGAIN' && code !== 'EWOULDBLOCK') {
        throw writeError;
      }
      await new Promise<void>((resolve) => setTimeout(resolve, RAW_STDOUT_RETRY_DELAY_MS));
    }
  }
}

export function takeOverStdout(): void {
```

Around line 51:

```ts
export function restoreStdout(): void {
```

Make exactly this change; do not modify anything else.