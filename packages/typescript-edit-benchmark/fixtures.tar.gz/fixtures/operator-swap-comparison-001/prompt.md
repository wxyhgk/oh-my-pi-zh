# Fix a bug in `restore-sandbox-env.ts`

A comparison operator is subtly wrong.

Replace this (starting on line 29):

```ts
      if (idx >= 0) {
```

with:

```ts
      if (idx > 0) {
```

Make exactly this change; do not modify anything else.