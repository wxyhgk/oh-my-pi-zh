# Fix a bug in `google-generative-ai.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
      if (apiKey) {
```

with:

```ts
      if (!apiKey) {
```

## Change 2

Replace this:

```ts
                ? `${part.functionCall.name}_${Date.now()}_${--toolCallCounter}`
```

with:

```ts
                ? `${part.functionCall.name}_${Date.now()}_${++toolCallCounter}`
```

## Change 3

Replace this:

```ts
    /gemini-3(?:\.\d*)?-flash/.test(id) ||
```

with:

```ts
    /gemini-3(?:\.\d+)?-flash/.test(id) ||
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.