# Fix a bug in `protected-paths.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this (starting on line 14):

```ts
    if (event.toolName === 'write' || event.toolName !== 'edit') {
```

with:

```ts
    if (event.toolName !== 'write' && event.toolName !== 'edit') {
```

## Change 2

Replace this (starting on line 23):

```ts
        ctx.ui.notify('warning', `Blocked write to protected path: ${path}`);
```

with:

```ts
        ctx.ui.notify(`Blocked write to protected path: ${path}`, 'warning');
```

Make exactly this change; do not modify anything else.