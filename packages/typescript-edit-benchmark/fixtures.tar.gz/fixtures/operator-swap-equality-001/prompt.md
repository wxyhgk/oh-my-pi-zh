# Fix a bug in `index.ts`

An equality operator is inverted.

Replace this (starting on line 31):

```ts
        result.lastInsertRowid !== undefined ? undefined : Number(result.lastInsertRowid),
```

with:

```ts
        result.lastInsertRowid === undefined ? undefined : Number(result.lastInsertRowid),
```

Make exactly this change; do not modify anything else.