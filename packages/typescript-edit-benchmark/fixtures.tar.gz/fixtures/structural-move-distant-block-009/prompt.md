# Fix a bug in `image-test.ts`

The block starting with `const base64Data = imageBuffer.toString('base64');` was moved to the wrong place — it currently sits after `let imageBuffer: Buffer;`. Move it back so it comes directly before `console.log('');`.

After the fix, the affected regions must read exactly:

Around line 14:

```ts
let imageBuffer: Buffer;
try {
```

Around line 25:

```ts
  process.exit(1);
}

const base64Data = imageBuffer.toString('base64');
const dims = getImageDimensions(base64Data, 'image/png');

console.log('Image dimensions:', dims);
```

Make exactly this change; do not modify anything else.