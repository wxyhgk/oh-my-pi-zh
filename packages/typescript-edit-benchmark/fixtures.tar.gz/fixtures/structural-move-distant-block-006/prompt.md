# Fix a bug in `rpc-process.ts`

The block starting with `if (!parsed.id) {` was moved to the wrong place — it currently sits after `pending.resolve(parsed as RpcResponse);`. Move it back so it comes directly before `const pending = this.pendingRequests.get(parsed.id);`.

After the fix, the affected regions must read exactly:

Around line 108:

```ts
      case 'response': {
        if (!parsed.id) {
          return;
        }
```

Around line 114:

```ts
        pending.resolve(parsed as RpcResponse);
```

Make exactly this change; do not modify anything else.