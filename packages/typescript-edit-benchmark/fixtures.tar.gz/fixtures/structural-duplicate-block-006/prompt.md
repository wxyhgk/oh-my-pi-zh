# Fix a bug in `daxnuts.ts`

The block starting with `if (i < revealedRows) {` appears twice in a row — the second copy is a copy-paste accident. Delete the second copy and keep the first.

After the fix, the affected region must read exactly:

Around line 128:

```ts
      }
```

Make exactly this change; do not modify anything else.