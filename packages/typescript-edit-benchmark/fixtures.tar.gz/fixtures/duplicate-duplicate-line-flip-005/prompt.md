# Fix a bug in `mime.ts`

One copy of a line that repeats elsewhere in this file was altered.

Replace this (starting on line 51):

```ts
    if (startsWithAscii(buffer, chunkTypeOffset, 'acTL')) return false;
```

with:

```ts
    if (startsWithAscii(buffer, chunkTypeOffset, 'acTL')) return true;
```

Make exactly this change; do not modify anything else.