# Fix a bug in `summarize.ts`

The block starting with `const extractTextParts = (content: unknown): string[] => {` was moved to the wrong place — it currently sits after `].join('\n');`. Move it back so it comes directly before `const extractToolCallLines = (content: unknown): string[] => {`.

After the fix, the affected regions must read exactly:

Around line 22:

```ts
const extractTextParts = (content: unknown): string[] => {
  if (typeof content === 'string') {
    return [content];
  }

  if (!Array.isArray(content)) {
    return [];
  }

  const textParts: string[] = [];
  for (const part of content) {
    if (!part || typeof part !== 'object') {
      continue;
    }

    const block = part as ContentBlock;
    if (block.type === 'text' && typeof block.text === 'string') {
      textParts.push(block.text);
    }
  }

  return textParts;
};

const extractToolCallLines = (content: unknown): string[] => {
```

Around line 94:

```ts
const showSummaryUi = async (summary: string, ctx: ExtensionCommandContext) => {
```

Make exactly this change; do not modify anything else.