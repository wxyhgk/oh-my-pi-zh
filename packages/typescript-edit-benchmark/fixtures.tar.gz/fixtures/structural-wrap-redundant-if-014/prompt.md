# Fix a bug in `rpc-process.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 87 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 87:

```ts
      this.exited = true;
      const wrapped = new Error(
        `RPC process error: ${error.message}. Stderr: ${this.stderrBuffer}`,
      );
      this.rejectAllPending(wrapped);
      this.notifyExit(wrapped);
```

Make exactly this change; do not modify anything else.