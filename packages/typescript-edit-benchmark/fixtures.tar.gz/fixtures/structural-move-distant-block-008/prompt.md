# Fix a bug in `server.ts`

The block starting with `const rpcStream = handler.openRpcStream(` was moved to the wrong place — it currently sits after `socket.once('close', () => rpcStream.close());`. Move it back so it comes directly before `if (!rpcStream) {`.

After the fix, the affected regions must read exactly:

Around line 87:

```ts
          socket.removeAllListeners('data');
          const rpcStream = handler.openRpcStream(
            request.instanceId,
            (response) => {
              socket.write(encodeMessage(response));
            },
            (event) => {
              socket.write(encodeMessage(event));
            },
            (request) => {
              socket.write(encodeMessage(request));
            },
          );
```

Around line 138:

```ts
          socket.once('close', () => rpcStream.close());
```

Make exactly this change; do not modify anything else.