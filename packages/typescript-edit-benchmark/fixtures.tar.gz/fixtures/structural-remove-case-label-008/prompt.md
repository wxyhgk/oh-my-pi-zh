# Fix a bug in `session-materialized.ts`

In this file's `switch`, the value in `case 'thinking_level_change':` must be handled exactly like the case after it: add a fall-through `case 'thinking_level_change':` label directly before `case 'message':`.

After the fix, the affected region must read exactly:

Around line 367:

```ts
    case 'model_change':
    case 'thinking_level_change':
    case 'message':
```

Make exactly this change; do not modify anything else.