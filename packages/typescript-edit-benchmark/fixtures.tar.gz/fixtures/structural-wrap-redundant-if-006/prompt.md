# Fix a bug in `status-indicator.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 95 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 95:

```ts
    super(
      'branchSummary',
      ui,
      (spinner) => theme.fg('accent', spinner),
      (text) => theme.fg('muted', text),
      `Summarizing branch... (${keyText('app.interrupt')} to cancel)`,
    );
```

Make exactly this change; do not modify anything else.