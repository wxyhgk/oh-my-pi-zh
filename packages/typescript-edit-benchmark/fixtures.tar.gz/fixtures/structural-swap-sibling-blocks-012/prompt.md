# Fix a bug in `index.ts`

Two adjacent blocks are in the wrong order: the block starting with `if (context.systemPrompt) {` belongs before the block starting with `} else if (context.systemPrompt) {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 411:

```ts
      if (isOAuth) {
```

Around line 422:

```ts
            text: "You are Claude Code, Anthropic's official CLI for Claude.",
            cache_control: { type: 'ephemeral' },
          },
        ];
        if (context.systemPrompt) {
          params.system.push({
            type: 'text',
            text: sanitizeSurrogates(context.systemPrompt),
            cache_control: { type: 'ephemeral' },
          });
        }
```

Make exactly this change; do not modify anything else.