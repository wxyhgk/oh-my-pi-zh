# Fix a bug in `output-accumulator.ts`

The branch bodies of `if (newlines === 0) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected regions must read exactly:

Around line 172:

```ts
    if (newlines === 0) {
      this.currentLineBytes += bytes;
      this.hasOpenLine = true;
    } else {
```

Around line 176:

```ts
      this.hasOpenLine = tail.length > 0;
```

Make exactly this change; do not modify anything else.