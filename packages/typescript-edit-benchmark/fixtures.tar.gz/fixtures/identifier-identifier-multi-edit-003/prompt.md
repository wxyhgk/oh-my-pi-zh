# Fix a misspelled identifier in `config.ts`

A recent edit misspelled the identifier `uninstallStep` as `nuinstallStep` in 3 places.

Replace every occurrence of `nuinstallStep` with `uninstallStep`. Do not change anything else.