# Fix a bug in `ssh.ts`

The block starting with `...localRead,` appears twice in a row — the second copy is a copy-paste accident. Delete the second copy and keep the first.

After the fix, the affected region must read exactly:

Around line 150:

```ts
  });

  pi.registerTool({
```

Make exactly this change; do not modify anything else.