# Fix a bug in `snake.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
    if (savedState && savedState.gameOver) {
      // Resume from saved state, start paused
      this.state = savedState;
      this.paused = false;
```

with:

```ts
    if (savedState && !savedState.gameOver) {
      // Resume from saved state, start paused
      this.state = savedState;
      this.paused = true;
```

## Change 2

Replace this:

```ts
      this.version--;
```

with:

```ts
      this.version++;
```

## Change 3

Replace this:

```ts
    const effectiveWidth = Math.min(GAME_WIDTH, Math.floor((width - 4) * cellWidth));
```

with:

```ts
    const effectiveWidth = Math.min(GAME_WIDTH, Math.floor((width - 4) / cellWidth));
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.