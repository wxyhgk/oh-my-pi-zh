# Fix a bug in `utils.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 25 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 25:

```ts
  if (message.role !== 'assistant') return;
  if (!('content' in message) || !Array.isArray(message.content)) return;

  for (const block of message.content) {
    if (typeof block !== 'object' || block === null) continue;
    if (!('type' in block) || block.type !== 'toolCall') continue;
    if (!('arguments' in block) || !('name' in block)) continue;

    const args = block.arguments as Record<string, unknown> | undefined;
    if (!args) continue;

    const path = typeof args.path === 'string' ? args.path : undefined;
    if (!path) continue;

    switch (block.name) {
      case 'read':
        fileOps.read.add(path);
        break;
      case 'write':
        fileOps.written.add(path);
        break;
      case 'edit':
        fileOps.edited.add(path);
        break;
```

Make exactly this change; do not modify anything else.