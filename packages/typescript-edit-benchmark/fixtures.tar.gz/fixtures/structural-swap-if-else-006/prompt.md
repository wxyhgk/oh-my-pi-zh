# Fix a bug in `messages.ts`

The branch bodies of `if (msg.output) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected region must read exactly:

Around line 85:

```ts
    text += `\`\`\`\n${msg.output}\n\`\`\``;
  } else {
    text += '(no output)';
```

Make exactly this change; do not modify anything else.