# Fix a bug in `validation.ts`

One copy of a line that repeats elsewhere in this file was altered.

Replace this:

```ts
      if (value !== null) {
```

with:

```ts
      if (value === null) {
```

Make exactly this change; do not modify anything else.