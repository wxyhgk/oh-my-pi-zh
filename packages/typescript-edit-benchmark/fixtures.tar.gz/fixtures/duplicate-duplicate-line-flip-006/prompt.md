# Fix a bug in `interactive-shell.ts`

One copy of a line that repeats elsewhere in this file was altered.

The bug is in the `isInteractiveCommand` function.

Replace this:

```ts
      return false;
```

with:

```ts
      return true;
```

Make exactly this change; do not modify anything else.