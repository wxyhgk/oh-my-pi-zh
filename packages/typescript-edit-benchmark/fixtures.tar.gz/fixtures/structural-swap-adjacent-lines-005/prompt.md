# Fix a bug in `system-prompt.ts`

Two adjacent statements are in the wrong order: `lines.push(`    <name>${escapeXml(skill.name)}</name>`);` belongs before `lines.push(`    <description>${escapeXml(skill.description)}</description>`);`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 17:

```ts
    lines.push(`    <name>${escapeXml(skill.name)}</name>`);
    lines.push(`    <description>${escapeXml(skill.description)}</description>`);
```

Make exactly this change; do not modify anything else.