# Fix a misspelled identifier in `first-time-setup.ts`

A recent edit misspelled the identifier `keyData` as `ekyData` in 4 places.

Replace every occurrence of `ekyData` with `keyData`. Do not change anything else.