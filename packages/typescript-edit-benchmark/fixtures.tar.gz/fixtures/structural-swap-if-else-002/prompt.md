# Fix a bug in `rpc-demo.ts`

The branch bodies of `if (value) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected region must read exactly:

Around line 88:

```ts
        ctx.ui.notify(`You entered: ${value}`, 'info');
      } else {
        ctx.ui.notify('Input cancelled', 'info');
```

Make exactly this change; do not modify anything else.