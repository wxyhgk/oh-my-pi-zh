# Fix a bug in `frontmatter.ts`

Two adjacent blocks are in the wrong order: the block starting with `export const parseFrontmatter = <T extends Record<string, unknown> = Record<string, unknown>>(` belongs before the block starting with `export const stripFrontmatter = (content: string): string => parseFrontmatter(content).body;`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 11:

```ts
const extractFrontmatter = (content: string): { yamlString: string | null; body: string } => {
```

Around line 40:

```ts
export const parseFrontmatter = <T extends Record<string, unknown> = Record<string, unknown>>(
  content: string,
): ParsedFrontmatter<T> => {
  const { yamlString, body } = extractFrontmatter(content);
  if (!yamlString) {
    return { frontmatter: {} as T, body };
  }
  const parsed = parse(yamlString);
  return { frontmatter: (parsed ?? {}) as T, body };
};

export const stripFrontmatter = (content: string): string => parseFrontmatter(content).body;
```

Make exactly this change; do not modify anything else.