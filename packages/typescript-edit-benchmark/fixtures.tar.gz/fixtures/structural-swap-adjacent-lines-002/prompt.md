# Fix a bug in `footer.ts`

Two adjacent statements are in the wrong order: `import { areExperimentalFeaturesEnabled } from '../../../core/experimental.ts';` belongs before `import type { ReadonlyFooterDataProvider } from '../../../core/footer-data-provider.ts';`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 4:

```ts
import { areExperimentalFeaturesEnabled } from '../../../core/experimental.ts';
import type { ReadonlyFooterDataProvider } from '../../../core/footer-data-provider.ts';
```

Make exactly this change; do not modify anything else.