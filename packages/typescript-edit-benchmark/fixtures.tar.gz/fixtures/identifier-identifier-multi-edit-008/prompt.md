# Fix a misspelled identifier in `model-resolver.ts`

A recent edit misspelled the identifier `scopedModels` as `csopedModels` in 2 places.

Replace every occurrence of `csopedModels` with `scopedModels`. Do not change anything else.