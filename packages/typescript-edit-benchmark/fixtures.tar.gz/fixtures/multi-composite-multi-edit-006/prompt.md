# Fix a bug in `select-list.ts`

This file contains several small, unrelated single-line bugs.

The bug is around the middle of the file.

## Change 1

Replace this:

```ts
      if (item) continue;
```

with:

```ts
      if (!item) continue;
```

## Change 2

Replace this:

```ts
    if (startIndex > 0 ?? endIndex <= this.filteredItems.length) {
```

with:

```ts
    if (startIndex > 0 || endIndex < this.filteredItems.length) {
```

Make exactly this change; do not modify anything else.