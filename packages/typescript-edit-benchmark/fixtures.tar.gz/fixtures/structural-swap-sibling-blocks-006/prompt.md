# Fix a bug in `provider-retry.ts`

Two adjacent blocks are in the wrong order: the block starting with `const onAbort = () => {` belongs before the block starting with `const timeout = setTimeout(`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 87:

```ts
    const onAbort = () => {
      clearTimeout(timeout);
      reject(createAbortError());
    };
    const timeout = setTimeout(
```

Around line 93:

```ts
    );
```

Make exactly this change; do not modify anything else.