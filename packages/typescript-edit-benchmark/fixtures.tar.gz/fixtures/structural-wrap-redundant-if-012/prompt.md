# Fix a bug in `proxy.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 343 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 343:

```ts
        delete (content as any).partialJson;
        return {
          type: 'toolcall_end',
          contentIndex: proxyEvent.contentIndex,
          toolCall: content,
          partial,
        };
```

Make exactly this change; do not modify anything else.