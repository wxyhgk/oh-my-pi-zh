# Fix a bug in `doom-keys.ts`

Two adjacent blocks are in the wrong order: the block starting with `if (data === 'n' || data === 'N' || matchesKey(data, 'n') || matchesKey(data, Key.shift('n'))) {` belongs before the block starting with `// Other printable characters (for cheats)`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 94:

```ts
  // Y/N for prompts
```

Around line 99:

```ts
    return ['y'.charCodeAt(0)];
  }
  if (data === 'n' || data === 'N' || matchesKey(data, 'n') || matchesKey(data, Key.shift('n'))) {
    return ['n'.charCodeAt(0)];
  }
```

Make exactly this change; do not modify anything else.