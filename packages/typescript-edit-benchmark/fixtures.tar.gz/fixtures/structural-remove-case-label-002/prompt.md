# Fix a bug in `cli.ts`

In this file's `switch`, the value in `case 'info':` must be handled exactly like the case after it: add a fall-through `case 'info':` label directly before `case 'progress':`.

After the fix, the affected region must read exactly:

Around line 68:

```ts
            break;
          case 'info':
          case 'progress':
```

Make exactly this change; do not modify anything else.