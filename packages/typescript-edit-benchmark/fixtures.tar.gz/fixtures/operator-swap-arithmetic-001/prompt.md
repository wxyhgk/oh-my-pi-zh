# Fix a bug in `custom-footer.ts`

An arithmetic operator was swapped.

Replace this (starting on line 53):

```ts
              return [truncateToWidth(left - pad + right, width)];
```

with:

```ts
              return [truncateToWidth(left + pad + right, width)];
```

Make exactly this change; do not modify anything else.