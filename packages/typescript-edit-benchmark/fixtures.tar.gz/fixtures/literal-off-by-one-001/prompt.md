# Fix a bug in `context.ts`

A numeric boundary has an off-by-one error.

Replace this (starting on line 27):

```ts
      return typeof value === 'string' && value.trim().length > 1 ? value : undefined;
```

with:

```ts
      return typeof value === 'string' && value.trim().length > 0 ? value : undefined;
```

Make exactly this change; do not modify anything else.