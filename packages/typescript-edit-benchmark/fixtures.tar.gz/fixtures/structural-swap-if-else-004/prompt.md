# Fix a bug in `autocomplete.ts`

The branch bodies of `if (dir === '/') {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected region must read exactly:

Around line 665:

```ts
              relativePath = `/${name}`;
            } else {
              relativePath = `${dir}/${name}`;
```

Make exactly this change; do not modify anything else.