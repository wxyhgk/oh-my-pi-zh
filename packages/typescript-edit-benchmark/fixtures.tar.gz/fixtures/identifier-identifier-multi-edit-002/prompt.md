# Fix a misspelled identifier in `diff.ts`

A recent edit misspelled the identifier `removedLines` as `ermovedLines` in 4 places.

Replace every occurrence of `ermovedLines` with `removedLines`. Do not change anything else.