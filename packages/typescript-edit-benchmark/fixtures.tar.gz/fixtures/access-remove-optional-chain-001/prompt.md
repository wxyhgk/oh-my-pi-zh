# Fix a bug in `uuid.ts`

Optional chaining was removed from a property access.

Replace this (starting on line 5):

```ts
  if (globalThis.crypto.getRandomValues) {
```

with:

```ts
  if (globalThis.crypto?.getRandomValues) {
```

Make exactly this change; do not modify anything else.