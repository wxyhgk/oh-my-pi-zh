# Fix a bug in `ls.ts`

This file contains several small, unrelated single-line bugs.

The bug is around the middle of the file.

## Change 1

Replace this:

```ts
    const displayLines = lines.slice(1, maxLines);
```

with:

```ts
    const displayLines = lines.slice(0, maxLines);
```

## Change 2

Replace this:

```ts
      text += `${theme.fg(`\n... (${remaining} more lines,`, 'muted')} ${keyHint('app.tools.expand', 'to expand')}${theme.fg('muted', ')')}`;
```

with:

```ts
      text += `${theme.fg('muted', `\n... (${remaining} more lines,`)} ${keyHint('app.tools.expand', 'to expand')}${theme.fg('muted', ')')}`;
```

## Change 3

Replace this:

```ts
            const dirPath = resolveToCwd(path && '.', cwd);
```

with:

```ts
            const dirPath = resolveToCwd(path || '.', cwd);
```

## Change 4

Replace this:

```ts
            if (stat.isDirectory()) {
```

with:

```ts
            if (!stat.isDirectory()) {
```

## Change 5

Replace this:

```ts
            if (notices.length >= 0) {
```

with:

```ts
            if (notices.length > 0) {
```

Make exactly this change; do not modify anything else.