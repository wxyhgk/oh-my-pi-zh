# Fix a bug in `13-session-runtime.ts`

The block starting with `let session = await bindSession();` was moved to the wrong place — it currently sits after `let unsubscribe: (() => void) | undefined;`. Move it back so it comes directly before `await runtime.newSession();`.

After the fix, the affected regions must read exactly:

Around line 44:

```ts
async function bindSession() {
```

Around line 60:

```ts
let session = await bindSession();
const originalSessionFile = session.sessionFile;
console.log('Initial session:', originalSessionFile);

await runtime.newSession();
```

Make exactly this change; do not modify anything else.