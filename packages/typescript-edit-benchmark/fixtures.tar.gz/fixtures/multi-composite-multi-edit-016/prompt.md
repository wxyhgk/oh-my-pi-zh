# Fix a bug in `terminal.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
  private _kittyProtocolActive = true;
```

with:

```ts
  private _kittyProtocolActive = false;
```

## Change 2

Replace this:

```ts
    const shouldDisableKittyProtocol = this.keyboardProtocolPushed && this._kittyProtocolActive;
```

with:

```ts
    const shouldDisableKittyProtocol = this.keyboardProtocolPushed || this._kittyProtocolActive;
```

This file contains near-identical code in multiple places — edit exactly the block shown and nothing else.