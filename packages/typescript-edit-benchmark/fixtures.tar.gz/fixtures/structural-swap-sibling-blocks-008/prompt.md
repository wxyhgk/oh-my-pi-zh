# Fix a bug in `ansi-to-html.ts`

Two adjacent blocks are in the wrong order: the block starting with `function styleToInlineCSS(style: TextStyle): string {` belongs before the block starting with `function hasStyle(style: TextStyle): boolean {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 81:

```ts
function createEmptyStyle(): TextStyle {
```

Around line 103:

```ts
function styleToInlineCSS(style: TextStyle): string {
  const parts: string[] = [];
  if (style.fg) parts.push(`color:${style.fg}`);
  if (style.bg) parts.push(`background-color:${style.bg}`);
  if (style.bold) parts.push('font-weight:bold');
  if (style.dim) parts.push('opacity:0.6');
  if (style.italic) parts.push('font-style:italic');
  if (style.underline) parts.push('text-decoration:underline');
  return parts.join(';');
}

function hasStyle(style: TextStyle): boolean {
```

Make exactly this change; do not modify anything else.