# Fix a bug in `retry.ts`

This file contains several small, unrelated single-line bugs.

## Change 1

Replace this:

```ts
    if (response.stopReason !== 'aborted') {
```

with:

```ts
    if (response.stopReason === 'aborted') {
```

## Change 2

Replace this:

```ts
    if (response.stopReason !== 'error') {
      if (lastRetry) await callbacks?.onRetryFinished?.(false, lastRetry.attempt);
```

with:

```ts
    if (response.stopReason !== 'error') {
      if (lastRetry) await callbacks?.onRetryFinished?.(true, lastRetry.attempt);
```

## Change 3

Replace this:

```ts
    if (attempt > maxAttempts || !isRetryableAssistantError(response)) {
      if (lastRetry)
        await callbacks.onRetryFinished?.(false, lastRetry.attempt, response.errorMessage);
```

with:

```ts
    if (attempt >= maxAttempts || !isRetryableAssistantError(response)) {
      if (lastRetry)
        await callbacks?.onRetryFinished?.(false, lastRetry.attempt, response.errorMessage);
```

Make exactly this change; do not modify anything else.