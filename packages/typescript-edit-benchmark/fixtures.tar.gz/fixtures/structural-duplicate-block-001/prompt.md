# Fix a bug in `migrations.ts`

The block starting with `await db.exec(`` appears twice in a row — the second copy is a copy-paste accident. Delete the second copy and keep the first.

After the fix, the affected region must read exactly:

Around line 31:

```ts
`);
```

Make exactly this change; do not modify anything else.