# Fix a bug in `write.ts`

Two adjacent blocks are in the wrong order: the block starting with `function refreshWriteHighlightPrefix(cache: WriteHighlightCache): void {` belongs before the block starting with `function rebuildWriteHighlightCacheFull(`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 69:

```ts
function refreshWriteHighlightPrefix(cache: WriteHighlightCache): void {
  const prefixCount = Math.min(WRITE_PARTIAL_FULL_HIGHLIGHT_LINES, cache.normalizedLines.length);
  if (prefixCount === 0) return;
  const prefixSource = cache.normalizedLines.slice(0, prefixCount).join('\n');
  const prefixHighlighted = highlightCode(prefixSource, cache.lang);
  for (let i = 0; i < prefixCount; i++) {
    cache.highlightedLines[i] =
      prefixHighlighted[i] ?? highlightSingleLine(cache.normalizedLines[i] ?? '', cache.lang);
  }
}

function rebuildWriteHighlightCacheFull(
```

Around line 86:

```ts
function updateWriteHighlightCacheIncremental(
```

Make exactly this change; do not modify anything else.