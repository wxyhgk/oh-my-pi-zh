# Fix a bug in `get-current-time.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 9 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 9:

```ts
    try {
      const timeStr = date.toLocaleString('en-US', {
        timeZone: timezone,
        dateStyle: 'full',
        timeStyle: 'long',
      });
      return {
        content: [{ type: 'text', text: timeStr }],
        details: { utcTimestamp: date.getTime() },
      };
    } catch (_e) {
      throw new Error(`Invalid timezone: ${timezone}. Current UTC time: ${date.toISOString()}`);
```

Make exactly this change; do not modify anything else.