# Fix a bug in `minimal-mode.ts`

Two adjacent statements are in the wrong order: `const timeout = args.timeout as number | undefined;` belongs before `const timeoutSuffix = timeout ? theme.fg('muted', ` (timeout ${timeout}s)`) : '';`. Swap the two statements.

After the fix, the affected region must read exactly:

Around line 132:

```ts
      const timeout = args.timeout as number | undefined;
      const timeoutSuffix = timeout ? theme.fg('muted', ` (timeout ${timeout}s)`) : '';
```

Make exactly this change; do not modify anything else.