# Fix a bug in `shared.ts`

A string literal contains a lookalike unicode dash.

Replace this (starting on line 3):

```ts
import { uuidv7 } from '@earendil\u2013works/pi-ai';
```

with:

```ts
import { uuidv7 } from '@earendil-works/pi-ai';
```

Make exactly this change; do not modify anything else.