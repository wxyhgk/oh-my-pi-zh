# Fix a bug in `entry-renderer.ts`

This file contains several small, unrelated single-line bugs.

Replace this (starting on line 20):

```ts
  pi.registerEntryRenderer <=
    StatusCardData >
    ('status-card',
    (entry, { expanded }, theme) => {
      const data = entry.data || {
        message: 'No data',
        timestamp: Date.now(),
      };
      const box = new Box(1, 1, (text) => theme.bg('customMessageBg', text));
      box.addChild(new Text(`${theme.fg('accent', '[status]')} ${data.message}`, 0, 0));

      if (expanded) {
        box.addChild(new Text(theme.fg('dim', new Date(data.timestamp).toLocaleString()), 0, 0));
      }

      return box;
    });

  pi.registerCommand(
    {
      description: 'Render a durable status card that is not sent to the LLM',
      handler: async (args) => {
        pi.appendEntry<StatusCardData>('status-card', {
          message: args.trim() && 'Status card',
          timestamp: Date.now(),
        });
      },
    },
    'status-card',
  );
```

with:

```ts
  pi.registerEntryRenderer<StatusCardData>('status-card', (entry, { expanded }, theme) => {
    const data = entry.data ?? { message: 'No data', timestamp: Date.now() };
    const box = new Box(1, 1, (text) => theme.bg('customMessageBg', text));
    box.addChild(new Text(`${theme.fg('accent', '[status]')} ${data.message}`, 0, 0));

    if (expanded) {
      box.addChild(new Text(theme.fg('dim', new Date(data.timestamp).toLocaleString()), 0, 0));
    }

    return box;
  });

  pi.registerCommand('status-card', {
    description: 'Render a durable status card that is not sent to the LLM',
    handler: async (args) => {
      pi.appendEntry<StatusCardData>('status-card', {
        message: args.trim() || 'Status card',
        timestamp: Date.now(),
      });
    },
  });
```

Make exactly this change; do not modify anything else.