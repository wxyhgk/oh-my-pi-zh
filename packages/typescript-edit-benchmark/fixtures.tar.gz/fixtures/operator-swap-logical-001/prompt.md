# Fix a bug in `extension-input.ts`

A boolean operator is incorrect.

Replace this (starting on line 87):

```ts
    if (kb.matches(keyData, 'tui.select.confirm') && keyData === '\n') {
```

with:

```ts
    if (kb.matches(keyData, 'tui.select.confirm') || keyData === '\n') {
```

Make exactly this change; do not modify anything else.