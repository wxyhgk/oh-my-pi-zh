# Fix a bug in `agent-loop.ts`

In this file's `switch`, the value in `case 'text_start':` must be handled exactly like the case after it: add a fall-through `case 'text_start':` label directly before `case 'text_delta':`.

After the fix, the affected region must read exactly:

Around line 346:

```ts
      case 'text_start':
      case 'text_delta':
```

Make exactly this change; do not modify anything else.