# Fix a bug in `image-models.ts`

A leftover debugging wrapper is redundant: remove the `if (true) {` on line 27 together with its closing brace, and dedent the wrapped body one level.

After the fix, the affected region must read exactly:

Around line 27:

```ts
  const providerModels = imageModelRegistry.get(provider);
  return providerModels?.get(modelId as string) as ImagesModel<ImageModelApi<TProvider, TModelId>>;
```

Make exactly this change; do not modify anything else.