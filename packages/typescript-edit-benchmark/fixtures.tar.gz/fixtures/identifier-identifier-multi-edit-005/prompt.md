# Fix a misspelled identifier in `frontmatter.ts`

A recent edit misspelled the identifier `normalized` as `onrmalized` in 3 places.

Affected lines: 14, 18, 20.

Replace every occurrence of `onrmalized` with `normalized`. Do not change anything else.