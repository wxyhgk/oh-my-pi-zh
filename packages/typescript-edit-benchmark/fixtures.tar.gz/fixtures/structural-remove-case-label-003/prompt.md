# Fix a bug in `index.ts`

In this file's `switch`, the value in `case 'end_turn':` must be handled exactly like the case after it: add a fall-through `case 'end_turn':` label directly before `case 'pause_turn':`.

After the fix, the affected region must read exactly:

Around line 327:

```ts
  switch (reason) {
    case 'end_turn':
```

Make exactly this change; do not modify anything else.