# Fix a bug in `index.ts`

Two adjacent blocks are in the wrong order: the block starting with `const downloadModel = async (` belongs before the block starting with `pi.registerCommand('llama', {`. Swap the two blocks.

After the fix, the affected regions must read exactly:

Around line 138:

```ts
  const downloadModel = async (
    ctx: ExtensionCommandContext,
    ui: LlamaUi,
    client: LlamaClient,
  ): Promise<void> => {
    const huggingFace = new HuggingFaceClient(await findHuggingFaceToken());
    const selected = await ui.searchModels((query, signal) => huggingFace.search(query, signal));
    if (!selected) return;
    const parsed = parseHuggingFaceModel(selected);
    ui.showStatus('Loading model details', parsed.repository);
    const details = await huggingFace.details(parsed.repository);
    if (details.gated) {
      const approval =
        details.gated === 'manual' ? 'Manual approval is required' : 'Accept the access terms';
      const choice = await ui.select(
        `Hugging Face access required\n${details.id}\n\n${approval} at:\nhttps://huggingface.co/${details.id}\n\nThe llama.cpp server needs HF_TOKEN with access.`,
        ['Continue', 'Back'],
      );
      if (choice !== 'Continue') return;
    }
    let quantization = parsed.quantization;
    if (!quantization && details.quantizations.length > 0) {
      const options = details.quantizations.map((entry) => {
        const detail = [
          entry.size === undefined ? undefined : formatBytes(entry.size),
          entry.name === 'Q4_K_M' ? 'recommended' : undefined,
        ]
          .filter((value): value is string => Boolean(value))
          .join(' · ');
        return detail ? `${entry.name} · ${detail}` : entry.name;
      });
      const choice = await ui.select(`Select quantization\n${details.id}`, options);
      if (!choice) return;
      quantization = details.quantizations[options.indexOf(choice)]?.name;
      if (!quantization) return;
    }
    const model = quantization ? `${details.id}:${quantization}` : details.id;
    const result = await runWithProgress(ui, {
      title: 'Downloading model',
      model,
      initialMessage: 'Starting…',
      cancelTitle: 'Stop download?',
      cancelMessage: model,
      run: (signal, update) => client.downloadAndWait(model, update, signal),
      cancel: () => client.unload(model),
    });
    if (result.cancelled) return;
    await syncCatalog(ctx, client, result.value);
    ctx.ui.notify(`Downloaded ${model}`);
  };

  pi.registerCommand('llama', {
```

Around line 190:

```ts
  });
```

Make exactly this change; do not modify anything else.