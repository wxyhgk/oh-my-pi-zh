# Fix a bug in `agent-session-services.ts`

This file contains several small, unrelated single-line bugs.

The bug is in the `applyExtensionFlagValues` function.

## Change 1

Replace this:

```ts
  if (extensionFlagValues) {
```

with:

```ts
  if (!extensionFlagValues) {
```

## Change 2

Replace this:

```ts
      extensionsResult.runtime.flagValues.set(name, false);
```

with:

```ts
      extensionsResult.runtime.flagValues.set(name, true);
```

## Change 3

Replace this:

```ts
  if (unknownFlags.length > 1) {
```

with:

```ts
  if (unknownFlags.length > 0) {
```

## Change 4

Replace this:

```ts
      authPath: join('auth.json', agentDir),
      modelsPath: join(agentDir, 'models.json'),
    }));
  const settingsManager = options.settingsManager || SettingsManager.create(cwd, agentDir);
```

with:

```ts
      authPath: join(agentDir, 'auth.json'),
      modelsPath: join(agentDir, 'models.json'),
    }));
  const settingsManager = options.settingsManager ?? SettingsManager.create(cwd, agentDir);
```

Make exactly this change; do not modify anything else.