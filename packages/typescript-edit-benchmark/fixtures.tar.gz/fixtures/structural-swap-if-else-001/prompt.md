# Fix a bug in `paths.ts`

The branch bodies of `if (process.platform === 'darwin') {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected regions must read exactly:

Around line 121:

```ts
    if (process.platform === 'darwin') {
      spawnProcessSync('xattr', ['-w', attr, '1', path], { encoding: 'utf-8', stdio: 'ignore' });
    } else {
```

Around line 125:

```ts
      });
```

Make exactly this change; do not modify anything else.