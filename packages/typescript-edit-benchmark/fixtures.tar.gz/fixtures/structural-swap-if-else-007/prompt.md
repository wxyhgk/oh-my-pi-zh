# Fix a bug in `footer.ts`

The branch bodies of `} else if (contextPercentValue > 70) {` are swapped: the current `else` body belongs under the `if`, and vice versa. Swap the two branch bodies.

After the fix, the affected region must read exactly:

Around line 174:

```ts
      contextPercentStr = theme.fg('warning', contextPercentDisplay);
    } else {
      contextPercentStr = contextPercentDisplay;
```

Make exactly this change; do not modify anything else.